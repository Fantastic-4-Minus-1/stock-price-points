module.exports = {
  undefined: 'mongodb://localhost/robinhood',
  dev: 'localhost/DEV_DB_NAME',
  prod: 'localhost/PROD_DB_NAME',
};
